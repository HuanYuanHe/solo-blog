title: Dubbo-admin配置及安装
date: '2019-11-25 09:24:04'
updated: '2019-11-25 09:24:04'
tags: [dubbo]
permalink: /articles/2019/11/25/1574645044356.html
---
Dubbo介绍

当服务越来越多时，容量的评估，小服务资源的浪费等问题逐渐显现，此时需要增加一个调度中心基于访问压力实时管理集群容量，提供集群利用率。其中，用于提高机器利用率的资源调度和治理中心是关键。

Dubbo 是阿里巴巴开源项目的一个分布式服务框架。致力于提供高性能和透明化的RPC远程服务调用方案，以及SOA服务治理方案。简单的说，Dubbo就是个服务框架，如果没有分布式的需求，其实是不需要用的，只有在分布式的时候，才有Dubbo这样的分布式服务框架的需求，并且本质上是个服务调用的东西，说白了就是个远程服务调用的分布式框架（告别Web Service模式中的WSDL，以服务者与消费者的方式在Dubbo上注册）。

名词解释：

WSDL：Web Services Description Language，网络服务描述语言

RPC：Remote Procedure Call Protocol，远程过程调用协议

SOA：Service-Oriented Architecture，面向服务的体系结构
Dubbo工作原理：
Dubbo-admin配置及安装

调用关系说明：

1) 服务容器启动、加载和运行服务提供者；

2) 服务提供者在启动时，向注册中心注册自己提供的服务；

3) 服务消费者在启动时，向注册中心订阅自己所需的服务；

4) 注册中心返回服务提供者地址列表给消费者，如果有变更，注册中心将基于长连接推送变更给消费者；

5) 服务消费者从地址列表中，基于软负载均衡算法选一台服务提供者进行调用，如果调用失败再选另一台；

6) 服务消费者和服务提供者在内存中累计调用次数和调用时间，定时每分钟发送一次统计数据到监控中心。

Zookeeper的作用：

Zookeeper 作为一个分布式的服务框架，主要用来解决分布式集群中应用系统的一致性问题，它能提供基于类似于文件系统的目录节点树方式的数据存储，但是 Zookeeper 并不是用来专门存储数据的，它的作用主要是用来维护和监控你存储的数据的状态变化。通过监控这些数据状态的变化，从而可以达到基于数据的集群管理。

Dubbo和zookeeper啥关系？

简单来说打个比方：Dubbo就是动物园的动物，zookeeper是动物园。如果游客想看动物的话那么就去动物园看。比如你要看老虎，那么动物园有你才能看到。换句话说我们把很多不同的Dubbo（动物）放到zookeeper（动物园中）提供给我们游客进行观赏。这个过程中三个关键：场所、供给者、消费者。

再说一个分布式的项目，server（消费）层与 service（供给）层被拆分了开来， 部署在不同的tomcat中， 我在server层需要调用 service层的接口，但是两个运行在不同tomcat下的服务无法直接互调接口，那么就可以通过zookeeper和Dubbo实现。就好比把动物放到动物园，我们要看了直接去动物园就行。而不能直接到动物生活的地方去看，会有性命安全之忧（比如你去看老虎）。

我们通过Dubbo 建立service这个服务，并且到zookeeper上面注册，填写对应的zookeeper服务所在 的IP及端口号。

环境准备
JDK-1.8
Maven-3.5.3
Zookeeper-3.4.12
Tomcat-9——8月8日改：由于Dubbo-Admin替换为SpringBoot的新版本，不在需要依赖Tomcat运行，可以跳过安装
Dubbo-Admin——8月8日改：新版本的编译和执行，补充在末尾
## 一、安装Java
(可选) 卸载已有的open jdk

```
# rpm -qa | grep jdk
       java-1.6.0-openjdk-1.6.0.0-1.45.1.11.1.el6.i686
# yum -y remove java-1.6.0-openjdk-1.6.0.0-1.45.1.11.1.el6.i686
       remove java-1.6.0-openjdk-1.6.0.0-1.45.1.11.1.el6.i686
```
安装步骤， 请见 http://qiangsh.blog.51cto.com/3510397/1771748

第二步：安装Maven
Maven的下载地址是：http://maven.apache.org/download.cgi

下载最新版本的Maven-3.5.4.tar.gz

## 1. 安装Maven-3.5.4
```

#下载maven
cd /data/packages
wget http://mirrors.hust.edu.cn/apache/maven/maven-3/3.5.4/binaries/apache-maven-3.5.4-bin.tar.gz

#创建maven的工作路径
mkdir -p /usr/local/maven
tar -zvxf apache-maven-3.5.4-bin.tar.gz -C /usr/local/maven/

#做一个软链接，方便以后升级：
ln -s /usr/local/maven/apache-maven-3.5.4 /usr/local/maven/maven3
```
## 2. 修改系统环境变量

```
# vim /etc/profile

#在适当的位置添加
export M2_HOME=/usr/local/maven/maven3
export PATH=$M2_HOME/bin:$PATH

#执行以下命令，使修改生效：
# source /etc/profile
```
## 3. 验证安装

  mvn -v
## 4. 创建本地资源仓库

#在本地创建一个资源文件的下载目录：
```
mkdir -p /data/maven/local-Repository
```

#修改Maven配置文件：
```
vim /usr/local/maven/maven3/conf/settings.xml
```
  #个人配置如下：

```
　<localRepository>/data/maven/local-Repository</localRepository> 

　<mirror>
        <id>alimaven</id>
        <name>aliyun-maven</name>
        <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
        <mirrorOf>central</mirrorOf>
    </mirror>

 　<mirror>
   　　<id>repo2</id>
   　　<name>Maven Repository2</name>
   　　<url>http://repo2.maven.org/maven2/</url>
   　　<mirrorOf>central</mirrorOf>
　</mirror> 
```
第三步：搭建Zookeeper单机环境
Zookeeper下载地址：

https://www.apache.org/dyn/closer.cgi/zookeeper/

1. 安装Zookeeper

```
tar -zxvf zookeeper-3.4.13.tar.gz -C /usr/local/
mv  /usr/local/zookeeper-3.4.13  /usr/local/zookeeper
```
2. 创建Zookeeper项目目录

```
mkdir /data/zookeeper     #项目目录
mkdir  /data/zookeeper/zkdata          #存放快照日志
mkdir  /data/zookeeper/zkdatalog     #存放事物日志
```
3. 修改配置文件

```
#进入 /usr/local/zookeeper/conf目录，复制zoo_sample.cfg文件并改名为zoo.cfg。
cd /usr/local/zookeeper/conf
cp zoo_sample.cfg zoo.cfg
```

#修改zoo.cfg文件，需要修改以下几个地方：
```
# vim zoo.cfg

-----

tickTime=2000
initLimit=10
syncLimit=5
dataDir=/data/zookeeper/zkdata
dataLogDir=/data/zookeeper/zkdatalog
clientPort=12181
server.1=127.0.0.1:12888:13888
```
4. 配置zookeeper的环境变量

```
# vim /etc/profile
export ZOOKEEPER_HOME=/usr/local/zookeeper
export PATH=$PATH:$ZOOKEEPER_HOME/bin

# source /etc/profile
```
5. 启动Zookeeper

#进入bin目录
```
cd  /usr/local/zookeeper/bin
```

# 启动zookeeper服务
```
./zkServer.sh start
```

# 启动完成后，查看服务状态：
```
./zkServer.sh status
```
6. 配置 zookeeper 开机启动

```
echo '/usr/local/zookeeper/bin/zkServer.sh start' >>/etc/rc.local 
```
第四步：安装Dubbo-Admin
为了更好的调试、发现问题、解决问题，因此引入dubbo-admin。通过dubbo-admin可以对消费者和提供者进行管理。

1. 下载Dubbo-Admin

#下载
```
cd /opt
git clone https://github.com/apache/incubator-Dubbo-ops
```
2. 修改配置信息

```
cd /opt/incubator-Dubbo-ops/dubbo-admin/src/main/resources
vim application.properties
```
Dubbo-admin配置及安装
需要注意的地方是：

默认的访问端口为7001；
Zookeeper的地址，如果zkServer和Dubbo-Admin不在同一台机器上，需要修改成zkServer所在的IP地址；
用户root、guest的密码酌情修改。
3: 编译

```
cd /opt/incubator-Dubbo-ops/
mvn package 
```
完成后，编译获得dubbo-admin-0.0.1-SNAPSHOT.jar，可以直接运行，不需要依赖Tomcat。

ls /opt/incubator-Dubbo-ops/dubbo-admin/target
classes                                  generated-sources       maven-status
dubbo-admin-0.0.1-SNAPSHOT.jar           generated-test-sources  surefire-reports
dubbo-admin-0.0.1-SNAPSHOT.jar.original  maven-archiver          test-classes
4: 启动

#将这个jar包复制到合适的路径下，如/usr/local/dubbo-admin/
```
mkdir /usr/local/dubbo-admin
cp /opt/incubator-Dubbo-ops/dubbo-admin/target/dubbo-admin-0.0.1-SNAPSHOT.jar /usr/local/dubbo-admin/
```

#然后启动服务
```
nohup java -jar /usr/local/dubbo-admin/dubbo-admin-0.0.1-SNAPSHOT.jar &
```

#加入开机自启：
```
echo 'nohup java -jar /usr/local/dubbo-admin/dubbo-admin-0.0.1-SNAPSHOT.jar &' >>/etc/rc.local 
```
在启动run-DubboAdmin.sh之前我们需要先把Zookeeper启动起来，之后我们就可以访问Dubbo-admin了。

会生成日志文件：dubbo-governance.log，记录启动和访问的记录。

确认关闭了防火墙，或者允许7001端口的通讯。

在浏览器输入：http://your_ip:7001；输入用户名root和密码后，显示主页：

有个最简单的方法就是安装完Java编译环境后，直接找其他同事的dubbo-admin-0.0.1-SNAPSHOT.jar 这个包，运行nohup java -jar /usr/local/dubbo-admin/dubbo-admin-0.0.1-SNAPSHOT.jar &即可部署dubbo-admin界面
